#sudo kubectl create -f /home/vagrant/kmaster/yamls/mysql.yaml
sudo kubectl create -f /home/vagrant/kmaster/yamls/keycloak.yaml