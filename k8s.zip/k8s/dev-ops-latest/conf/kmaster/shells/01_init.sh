#https://github.com/kubernetes-sigs/nfs-subdir-external-provisioner
#kubectl get sc
#kubectl get pv,pvc
#kubectl get pods

#kubectl describe sa admin-user -n kubernetes-dashboard
#kubectl describe secret admin-user-token-jdt2k -n kubernetes-dashboard

#kubectl -n kubernetes-dashboard delete serviceaccount admin-user
#kubectl -n kubernetes-dashboard delete clusterrolebinding admin-user

echo "kubelet calico deployment !"
sudo kubectl create -f /home/vagrant/kmaster/yamls/calico.yaml
echo "kubelet metallb deployment !"
sudo kubectl create -f /home/vagrant/kmaster/yamls/metallb.yaml
echo "kubelet external-dns deployment !"
sudo kubectl create -f /home/vagrant/kmaster/yamls/external-dns.yaml
echo "kubelet external-dns nfs-provisioner.yaml !"
sudo kubectl create -f /home/vagrant/kmaster/yamls/nfs-provisioner.yaml
echo "kubelet dashboard !"
sudo kubectl create -f /home/vagrant/kmaster/yamls/kube-dashboard.yaml