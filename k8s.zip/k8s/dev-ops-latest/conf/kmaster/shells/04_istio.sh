curl -L https://istio.io/downloadIstio | sh -
cd istio-1.11.4
export PATH=$PWD/bin:$PATH
istioctl  install --set profile=demo -y
istioctl verify-install
kubectl get all -n istio-system
cd samples/addons
kubectl apply -f kiali.yaml -f jaeger.yaml -f prometheus.yaml -f grafana.yaml