kubectl create namespace ingress-nginx
helm install my-ingress-nginx ingress-nginx/ingress-nginx -n ingress-nginx --values /home/vagrant/kmaster/helm/ingress-values.yaml
#helm list -n ingress-nginx
#helm uninstall my-ingress-nginx -n ingress-nginx
#kubectl get all -n ingress-nginx