#!/bin/bash

## !IMPORTANT ##
#
## This script is tested only in the generic/ubuntu2004 Vagrant box
## If you use a different version of Ubuntu or a different Ubuntu Vagrant box test this again
#

echo "[TASK 1] Enable and Load Kernel modules"
sed -i '/swap/d' /etc/fstab
swapoff -a
cat >>/etc/modules-load.d/containerd.conf<<EOF
overlay
br_netfilter
EOF
modprobe overlay
modprobe br_netfilter
cat >>/etc/sysctl.d/kubernetes.conf<<EOF
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables  = 1
net.ipv4.ip_forward                 = 1
EOF
sysctl --system >/dev/null 2>&1

echo "[TASK 2] Install containerd runtime"
echo "  containerd install start !"
apt install -qq -y containerd apt-transport-https
echo "  containerd install completed !"
mkdir /etc/containerd
containerd config default > /etc/containerd/config.toml
systemctl restart containerd
systemctl enable containerd

echo "[TASK 3] Install Kubernetes components (kubeadm, kubelet and kubectl)"
echo "  kubeadm,kubelet,kubectl install start !"
curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -
apt-add-repository "deb http://apt.kubernetes.io/ kubernetes-xenial main"
apt update -qq
apt install -qq -y kubeadm=1.22.0-00 kubelet=1.22.0-00 kubectl=1.22.0-00
echo "Environment=\"KUBELET_EXTRA_ARGS=--node-ip=172.16.16.151\"" >> /etc/systemd/system/kubelet.service.d/10-kubeadm.conf
systemctl daemon-reload
systemctl restart kubelet
echo "  kubeadm,kubelet,kubectl install completed !"

echo "[TASK 4] Join to Kubernetes cluster"
apt install -qq -y sshpass
sshpass -p "venkat" scp -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no 172.16.16.101:/joincluster.sh /joincluster.sh
bash /joincluster.sh

echo "[TASK 5] Configure DNS Server."
rm -rf /etc/resolv.conf
echo "nameserver 172.16.16.7" > /etc/resolv.conf
echo "nameserver 8.8.8.8" >> /etc/resolv.conf
echo "nameserver 1.1.1.1" >> /etc/resolv.conf

echo "[TASK 6] Configure nfs client."
sudo apt install -y nfs-common