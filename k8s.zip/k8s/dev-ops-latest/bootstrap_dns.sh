#!/bin/bash

## !IMPORTANT ##
#
## This script is tested only in the generic/ubuntu2004 Vagrant box
## If you use a different version of Ubuntu or a different Ubuntu Vagrant box test this again
#
date
echo "[TASK 1] Stop local dns service."
systemctl disable systemd-resolved >/dev/null 2>&1
systemctl stop systemd-resolved >/dev/null 2>&1
rm -f /etc/resolv.conf
echo "nameserver 127.0.0.1" > /etc/resolv.conf
echo "nameserver 8.8.8.8" >> /etc/resolv.conf
echo "nameserver 1.1.1.1" >> /etc/resolv.conf

echo "[TASK 2] Install PowerDNS & MariaDB."
echo "  pdns-server install start !"
apt install -qq -y pdns-server >/dev/null 2>&1
echo "  pdns-server install completed !"
echo "  pdns-backend-mysql install start !"
apt install -qq -y pdns-backend-mysql >/dev/null 2>&1
echo "  pdns-backend-mysql install completed !"
echo "  mariadb-server install start !"
apt install -qq -y mariadb-server >/dev/null 2>&1
echo "  mariadb-server install completed !"

echo "[TASK 3] PowerDNS configure."
echo "CREATE USER 'powerdns'@'localhost' IDENTIFIED BY 'venkat'" | sudo mysql -uroot 
echo "CREATE DATABASE powerdns" | sudo mysql -uroot
echo "GRANT ALL ON powerdns.* TO 'powerdns'@'localhost' IDENTIFIED BY 'venkat'" | sudo mysql -uroot
echo "flush privileges" | sudo mysql -uroot
sudo mysql -uroot powerdns < /home/vagrant/pdns/pdns.sql
cat >>/etc/powerdns/pdns.d/mysql.conf<<EOF
# MySQL Configuration
# Launch gmysql backend
launch+=gmysql
# gmysql parameters
gmysql-host=localhost
gmysql-port=3306
gmysql-dbname=powerdns
gmysql-user=powerdns
gmysql-password=venkat
gmysql-dnssec=yes
# gmysql-socket=
EOF
systemctl restart pdns


echo "[TASK 4] Install PowerDNS-Admin {python3, libs, virtualenv, nodejs, nginx  & powerdns-admin}."
echo "  python3-dev install start !"
apt install -qq -y python3-dev >/dev/null 2>&1
echo "  python3-dev install completed !"

echo "  libs & virtualenv install start !"
apt install -qq -y libmysqlclient-dev libsasl2-dev libldap2-dev libssl-dev libxml2-dev libxslt1-dev libxmlsec1-dev libffi-dev pkg-config apt-transport-https virtualenv build-essential >/dev/null 2>&1
echo "  libs & virtualenv install completed !"

echo "  nodejs & yarn install start !"
curl -sL https://deb.nodesource.com/setup_14.x | bash - >/dev/null 2>&1
curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add - >/dev/null 2>&1
echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list >/dev/null 2>&1
apt update -qq >/dev/null 2>&1
apt install -qq -y nodejs >/dev/null 2>&1
apt install -qq -y yarn >/dev/null 2>&1
echo "  nodejs & yarn install completed !"

echo "  nginx install start !"
apt install -y nginx >/dev/null 2>&1
echo "  nginx install completed !"

echo "  powerdns-admin install start !"
git clone https://github.com/ngoduykhanh/PowerDNS-Admin.git /opt/web/powerdns-admin >/dev/null 2>&1
cd /opt/web/powerdns-admin
virtualenv -p python3 flask >/dev/null 2>&1
source ./flask/bin/activate
echo "   install python3 requirements packages start !"
pip install -r requirements.txt >/dev/null 2>&1
echo "   install python3 requirements packages completed !"
deactivate
echo "  powerdns-admin install completed !"

echo "[TASK 5] PowerDNS-Admin configure."
cd /opt/web/powerdns-admin/powerdnsadmin
sed -i "s/BIND_ADDRESS =.*/BIND_ADDRESS = '172.16.16.7'/g" default_config.py
sed -i "s/SQLA_DB_USER =.*/SQLA_DB_USER = 'powerdns'/g" default_config.py
sed -i "s/SQLA_DB_PASSWORD =.*/SQLA_DB_PASSWORD = 'venkat'/g" default_config.py
sed -i "s/SQLA_DB_NAME =.*/SQLA_DB_NAME = 'powerdns'/g" default_config.py
cd /opt/web/powerdns-admin
source ./flask/bin/activate
export FLASK_APP=powerdnsadmin/__init__.py
echo "   flask db start !"
flask db upgrade >/dev/null 2>&1
flask db migrate -m "Init DB" >/dev/null 2>&1
echo "   flask db completed !"
echo "   yarn install pure-lockfile start !"
yarn install --pure-lockfile >/dev/null 2>&1
echo "   yarn install pure-lockfile completed !"
echo "   flask assets build start !"
flask assets build >/dev/null 2>&1
deactivate
echo "   flask assets build completed !"

echo "[TASK 6] PowerDNS-Admin--Configure systemd services."
cp /home/vagrant/pdns/powerdns-admin.service /etc/systemd/system/powerdns-admin.service
cat >>/etc/systemd/system/powerdns-admin.socket<<EOF
[Unit]
Description=PowerDNS-Admin socket

[Socket]
ListenStream=/run/powerdns-admin/socket

[Install]
WantedBy=sockets.target
EOF
cat >>/etc/tmpfiles.d/powerdns-admin.conf<<EOF
d /run/powerdns-admin 0755 pdns pdns -
EOF
systemctl daemon-reload
systemctl restart powerdns-admin
systemctl enable powerdns-admin
chown -R pdns:pdns /run/powerdns-admin
chown -R pdns:pdns /opt/web/powerdns-admin
echo 'api=yes' >> /etc/powerdns/pdns.conf
echo 'api-key=789456123741852963' >> /etc/powerdns/pdns.conf
echo 'webserver=yes' >> /etc/powerdns/pdns.conf
echo 'webserver-address=0.0.0.0' >> /etc/powerdns/pdns.conf
echo 'webserver-allow-from=0.0.0.0/0,::/0' >> /etc/powerdns/pdns.conf
echo 'webserver-port=8081' >> /etc/powerdns/pdns.conf
cp /home/vagrant/pdns/powerdns-admin.conf /etc/nginx/conf.d/powerdns-admin.conf
cd /etc/powerdns/
chmod -R 777 *.*
systemctl daemon-reload
systemctl restart powerdns-admin
systemctl enable powerdns-admin
systemctl restart pdns
systemctl enable pdns
systemctl restart nginx
systemctl enable nginx
sudo nginx -t
#http://www.powerdns-admin.example.com

echo "[TASK 7] Install NFS Server ."
sudo apt install -qq -y nfs-kernel-server
sudo mkdir /srv/nfs/kubedata -p
sudo chown nobody /srv/nfs/kubedata/
sudo chmod -R 777 /srv/nfs/kubedata/
echo "/srv/nfs/kubedata         *(rw,sync,no_subtree_check,no_root_squash,no_all_squash,insecure)" >> /etc/exports
sudo systemctl enable --now nfs-server
sudo exportfs -rav
sudo systemctl restart nfs-server

echo "[TASK 8] Keycloak Config."
echo "CREATE USER 'keycloak'@'%' IDENTIFIED BY 'venkat'" | sudo mysql -uroot 
echo "CREATE DATABASE keycloak" | sudo mysql -uroot
echo "GRANT ALL ON keycloak.* TO 'keycloak'@'%' IDENTIFIED BY 'venkat'" | sudo mysql -uroot
echo "GRANT ALL PRIVILEGES ON mysql.* TO 'keycloak'@'%'" | sudo mysql -uroot
echo "flush privileges" | sudo mysql -uroot
cp /etc/mysql/mariadb.conf.d/50-server.cnf /etc/mysql/mariadb.conf.d/50-server.cnf_bkp
sed -i 's/^bind-address .*/#bind-address/' /etc/mysql/mariadb.conf.d/50-server.cnf
systemctl restart mariadb
date 